from .gemini import GeminiLLM
from .groq import GroqLLM
from .deepseek import DeepSeekLLM
from .qwen import QwenScoreModel


def build_main_llm(cfg):
    provider = cfg.get("provider")
    if provider == "gemini":
        return GeminiLLM(cfg)
    if provider == "groq":
        return GroqLLM(cfg)
    if provider == "deepseek":
        return DeepSeekLLM(cfg)
    raise ValueError(f"Unknown main_llm.provider: {provider}")


def build_score_model(cfg):
    provider = cfg.get("provider", "none")
    if provider in {None, "none"}:
        return None
    if provider in {"qwen", "qwen8b"}:
        return QwenScoreModel(cfg)
    raise ValueError(f"Unknown score_model.provider: {provider}")
